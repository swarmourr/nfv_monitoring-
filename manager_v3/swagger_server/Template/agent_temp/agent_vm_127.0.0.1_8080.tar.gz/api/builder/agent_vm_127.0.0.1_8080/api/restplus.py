from flask_restplus import Api

api = Api(version='1.0', title='monitoring', description='Agent Monitoring ')
# api.__schema__
